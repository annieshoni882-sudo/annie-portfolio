# Annie Shoni - Portfolio Website

A professional, feature-rich portfolio website for Annie Shoni - HR Specialist, Educator, and Counsellor.

## Features

- **Dark Theme** (default) with **Light Mode** toggle
- **Scroll Animations** using AOS library
- **Typing Effect** in hero section
- **Progress Bars** for skills
- **Floating Particles** animation
- **Custom Cursor** (desktop only)
- **Loading Screen** animation
- **Scroll Progress Bar**
- **Back to Top** button
- **Mobile Responsive** design with hamburger menu
- **Contact Form** with mailto integration
- **Professional Timeline** for experience
- **Animated Skill Bars** with shimmer effect
- **Social Media Links** with hover animations
- **Parallax Effects** on hero background
- **Language Tags** showing multilingual skills

## Files

- `index.html` - Main HTML file
- `styles.css` - All CSS styles
- `script.js` - All JavaScript functionality
- `annie.png` - Profile picture (you need to add this)

## How to Host on GitHub Pages (Step-by-Step for Beginners)

### Step 1: Create a GitHub Account
1. Go to https://github.com
2. Click "Sign up" in the top right
3. Enter your email, create a password, and choose a username
4. Verify your email address

### Step 2: Create a New Repository
1. Log in to GitHub
2. Click the **+** button (top right) → "New repository"
3. Name it: `annie-portfolio` (or any name you like)
4. Make it **Public** (so GitHub Pages can host it)
5. Check the box: **"Add a README file"**
6. Click **"Create repository"**

### Step 3: Upload Your Files
1. In your new repository, click **"Add file"** → **"Upload files"**
2. Drag and drop these files from your computer:
   - `index.html`
   - `styles.css`
   - `script.js`
   - `annie.png` (your sister's photo - make sure it's named exactly `annie.png`)
3. Scroll down and click **"Commit changes"**

### Step 4: Enable GitHub Pages
1. Go to your repository's **Settings** tab (top right)
2. Scroll down to the **"Pages"** section (left sidebar)
3. Under **"Source"**, select **"Deploy from a branch"**
4. Select **"main"** branch and **"/ (root)"** folder
5. Click **"Save"**
6. Wait 2-5 minutes for the site to build
7. Your website will be live at: `https://yourusername.github.io/annie-portfolio/`

### Step 5: Update Your Sister's Photo
1. Make sure the photo is named exactly `annie.png`
2. The photo should be a square image (recommended: 500x500 pixels or larger)
3. Upload it to the repository along with the other files
4. If the photo doesn't show up, check that the filename is exactly `annie.png` (case-sensitive)

## Customization Tips

### To Change Colors:
Edit the CSS variables in `styles.css`:
```css
:root {
    --primary: #6366f1;        /* Main purple color */
    --secondary: #ec4899;      /* Pink accent */
    --accent: #06b6d4;         /* Cyan accent */
}
```

### To Update Content:
Edit `index.html` and look for sections like:
- Experience details
- Skills percentages
- Education information
- Contact details

### To Add More Social Links:
Find the social links in the HTML and add more:
```html
<a href="your-link" class="social-link"><i class="fab fa-icon-name"></i></a>
```

## Need Help?

- GitHub Pages documentation: https://pages.github.com
- Font Awesome icons: https://fontawesome.com/icons
- AOS Animation library: https://michalsnik.github.io/aos/

## Credits

Designed with care for Annie Shoni by her brother.
Built with HTML, CSS, and JavaScript.
